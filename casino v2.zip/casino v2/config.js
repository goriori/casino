window.API = 'https://api.slots-spincity.com'
window.TG_BOT = 'https://t.me/slotspincity_bot'
window.TG_SUPPORT = 'https://t.me/spincityhelp'
window.CEF = false
window.TIMEOUT = 90
window.IS_DEV = true


window.MIN_COUNT_REPLENISHMENT = 300
window.MAX_COUNT_REPLENISHMENT = 1000000
window.MIN_COUNT_WITHDRAWAL = 500
window.MAX_COUNT_WITHDRAWAL = 100000

window.CATEGORIES_ID = [26, 2, 15]
